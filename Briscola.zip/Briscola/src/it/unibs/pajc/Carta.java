package it.unibs.pajc;

import java.io.Serializable;

public class Carta implements Serializable{
	private String nome;
	private String seme;
	private int valore;
	public Carta(String seme, String nome, int valore) {
		super();
		this.nome = nome;
		this.seme = seme;
		this.valore = valore;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSeme() {
		return seme;
	}
	public void setSeme(String seme) {
		this.seme = seme;
	}
	public int getValore() {
		return valore;
	}
	public void setValore(int valore) {
		this.valore = valore;
	}

	@Override
	public String toString() {
		return "Carta [nome=" + nome + ", seme=" + seme + ", valore=" + valore + "]";
	}
	
	

}
