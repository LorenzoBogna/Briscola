package Server;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import it.unibs.pajc.Carta;

public class ClientHandler extends Thread {
    private DataInputStream in1;
    private DataOutputStream out1;
    private ObjectOutputStream objectOut1;
    private ObjectInputStream objectIn1;
    private Socket socketClient;
    
    private DataInputStream in2;
    private DataOutputStream out2;
    private ObjectOutputStream objectOut2;
    private ObjectInputStream objectIn2;
    
    private List<Socket> clientSocket;
    private List<Carta> listaCarteMazzo;
    private List<Carta> treCarte;
    private List<Carta> treCarte2;
    
    private int puntiPlayer1;
    private int puntiPlayer2;
    
    private boolean startGame = false;
    private boolean turnoPlayer1 = true; 
    private boolean turnoPlayer2 = false;  
    private Scanner sc;
    
    private Carta cartaGiocata1; // La carta giocata dal client
    private Carta cartaGiocata2;

    public ClientHandler(Socket socketClient, List<Socket> clientSocket, List<Carta> listaCarteMazzo) {
        this.socketClient = socketClient;
        this.clientSocket = clientSocket;
        this.listaCarteMazzo = listaCarteMazzo;   
    }

    @Override
    public void run() {
        try 
        {
            //inizio if sperimentale
            if(clientSocket.size()==2) {         	
           		System.out.println("Numero giocatori sufficiente");
           		Socket client1 = clientSocket.get(0);
           		Socket client2 = clientSocket.get(1);
           		startGame=true;
           		
           		in1 = new DataInputStream(client1.getInputStream());
                out1 = new DataOutputStream(client1.getOutputStream());
                objectOut1 = new ObjectOutputStream(out1);
                objectIn1 = new ObjectInputStream(in1);
                
                in2 = new DataInputStream(client2.getInputStream());
                out2 = new DataOutputStream(client2.getOutputStream());
                objectOut2 = new ObjectOutputStream(out2);
                objectIn2 = new ObjectInputStream(in2);
                
                List<Carta> carteDaRimuovere;
                
                treCarte = inviaTreCarteCasuali(listaCarteMazzo);
                for (Carta carta : treCarte) {                
                    objectOut1.writeObject(carta);
                    objectOut1.flush();   
                }
       		
       			carteDaRimuovere = new ArrayList<>();
                for (int i = 0; i < listaCarteMazzo.size(); i++) {
                    for (int j = 0; j < treCarte.size(); j++) {
                        if (listaCarteMazzo.get(i).equals(treCarte.get(j))) {
                            carteDaRimuovere.add(listaCarteMazzo.get(i));
                        }
                    }
                }
                // Rimuovi le carte dalla lista principale
                listaCarteMazzo.removeAll(carteDaRimuovere);
                
                treCarte2 = inviaTreCarteCasuali(listaCarteMazzo);
                for (Carta carta : treCarte2) {                
                    objectOut2.writeObject(carta);
                    objectOut2.flush();   
                }
                
                carteDaRimuovere = new ArrayList<>();
                for (int i = 0; i < listaCarteMazzo.size(); i++) {
                    for (int j = 0; j < treCarte2.size(); j++) {
                        if (listaCarteMazzo.get(i).equals(treCarte2.get(j))) {
                            carteDaRimuovere.add(listaCarteMazzo.get(i));
                        }
                    }
                }
                // Rimuovi le carte dalla lista principale
                listaCarteMazzo.removeAll(carteDaRimuovere);  		
                System.out.println("[4] Server - Rimangono nel mazzo: " + listaCarteMazzo.size() + " carte");
                                                
           		do {    
           			while(turnoPlayer1 && !turnoPlayer2) {
           				out1.writeUTF("\nGioca una carta player 1");
           				cartaGiocata1 = (Carta) objectIn1.readObject();
           				// Ora puoi stampare la carta giocata su server
           				System.out.println("Carta giocata da player 1: " + cartaGiocata1);  		
           				System.out.println("Player 1 aspetta che giochi il player 2");
           				out1.writeUTF("Player 1 aspetta che giochi il player 2");
           				turnoPlayer1=false;
           				turnoPlayer2=true;     				
           			}
           			//player 2	
           			while(turnoPlayer2 && !turnoPlayer1) {
           				out2.writeUTF("\nGioca una carta player 2");
           				cartaGiocata2 = (Carta) objectIn2.readObject();
           				// Ora puoi stampare la carta giocata su server
           				System.out.println("Carta giocata da player 2: " + cartaGiocata2);
           				System.out.println("Player 2 aspetta che giochi il player 1");
           				out2.writeUTF("Player 2 aspetta che giochi il player 1");	
           				turnoPlayer1=true;
           				turnoPlayer2=false;	
           			}
           			
           			int k=checkVincitore(cartaGiocata1, cartaGiocata2);
           			int parz=0;
           			parz=cartaGiocata1.getValore()+cartaGiocata2.getValore();
           			if(k==1){     				
           				System.out.println("IL vincitore è il giocatore 1 ");
           				System.out.println("Punti giocatore 1: " + puntiPlayer1+"\n");
           				out1.writeUTF("IL vincitore è il giocatore 1 ");
           				out2.writeUTF("IL vincitore è il giocatore 1 ");
           				out1.writeInt(parz);
           				out2.writeInt(0);
           				puntiPlayer1 += parz;
           				parz=0;
           			}
           			else {
           				System.out.println("IL vincitore è il giocatore 2 ");
           				System.out.println("Punti giocatore 2: " + puntiPlayer2 +"\n");
           				out1.writeUTF("IL vincitore è il giocatore 2 ");
           				out2.writeUTF("IL vincitore è il giocatore 2 ");
           				out1.writeInt(0);
           				out2.writeInt(parz);
           				puntiPlayer2 += parz;
           				parz=0;
           			}
           			
           			Carta newCarta1 = pescaCarta(listaCarteMazzo);
           			listaCarteMazzo.remove(0);          			
           			objectOut1.writeObject(newCarta1);
           			
           			Carta newCarta2 = pescaCarta(listaCarteMazzo);
           			listaCarteMazzo.remove(0);          			
           			objectOut2.writeObject(newCarta2);
       			
           			System.out.println("\n[4] Server - Rimangono nel mazzo: " + listaCarteMazzo.size() + " carte");
           			System.out.println("Punti player 1: " + puntiPlayer1);
           			System.out.println("Punti player 2: " + puntiPlayer2 + "\n");
           			       				
           		}while(puntiPlayer1 <= 60 && puntiPlayer2 <= 60);
           		
           		if(puntiPlayer1>60 ) {
           			System.out.println("Vince player 1");
           		}else if (puntiPlayer2>60) {
           			System.out.println("Vince player 2");
           		}else {
           			System.out.println("Patta");
           		}	
           	//if iniziale nuovo
           	}else {
           		System.out.println("Non ci sono abbastanza giocatori");
           		startGame=false;
            }
            //fine if nuovo
        }     
        catch (IOException | ClassNotFoundException e) 
        {
            e.printStackTrace();
        }
    }
    
    public List<Carta> inviaTreCarteCasuali(List<Carta> mazzo) {
        // Mescola il mazzo in modo casuale
        Collections.shuffle(mazzo);
        // Prendi le prime tre carte dal mazzo
        List<Carta> treCarte = mazzo.subList(0, 3);
        return treCarte;
    }
    
    public Carta pescaCarta(List<Carta> mazzo) {
    	Collections.shuffle(mazzo);
    	Carta carta = mazzo.get(0);
    	return carta;
    }
     
    public int checkVincitore(Carta c1, Carta c2) {
    	if(c1.getValore()>c2.getValore()) {
    		return 1;
    	}
    	else return 2;
    }  
}


