package Server;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import it.unibs.pajc.Carta;

public class Server {
	
	ServerSocket server = null;
	Socket socketClient = null;
	
	private int porta = 1235
			;
	private List<Socket> clientSocket;
	private List<Carta> listaCarteMazzo;
	
	Scanner sc; 
	
	public static void main(String[] args) {
		Server s = new Server();
		s.start();
	}

	public void start() {
		listaCarteMazzo = creaMazzo();
		
        try 
        {
            server = new ServerSocket(porta);
            System.out.println("[0] Server - Server attivo");
            System.out.println("[1] Server - Server pronto in ascolto su porta " + porta);
            
            clientSocket = new ArrayList<>();

            while (true) {
                Socket socketClient = server.accept();
                
                //sendMessageToAllClients(msg);
                
                System.out.println("\n[2] Server - Nuova connessione accettata");
                clientSocket.add(socketClient);

                ClientHandler clientHandler = new ClientHandler(socketClient, clientSocket, listaCarteMazzo);
                Thread clientThread = new Thread(clientHandler);
                clientThread.start();
                
            }
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        } 
        finally 
        {
            try 
            {
                server.close();
            } 
            catch (IOException e) 
            
            {
                e.printStackTrace();
            }
        }
    } 
	
	public List<Carta> creaMazzo() {
    	String[] seme = {"spade", "denara", "coppe", "bastoni"};
		String[] nome = {"due", "tre", "quattro", "cinque", "sei", "sette", "fante", "cavallo", "re", "asso"};
		int[] valore = {1,2,3,4,5,6,7,8,9,10,11};
		List<Carta> mazzo = new ArrayList<Carta>();
		int ind = 0;
		
		
		for (String semi : seme) {
			ind =2;
            for (String nomi : nome) {
            	Carta carta = new Carta(semi, nomi, ind);
            	ind++;
            	//carta.setValore(valore[ind]);
            	mazzo.add(carta);
                       
            }
        }	
		return mazzo;
    }

}