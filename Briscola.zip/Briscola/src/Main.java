import java.util.ArrayList;
import java.util.List;

import it.unibs.pajc.Carta;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] seme = {"spade", "denari", "coppe", "bastoni"};
		String[] nome = {"due", "tre", "quattro", "cinque", "sei", "sette", "fante", "cavallo", "re", "asso"};
		int[] valore = {1,2,3,4,5,6,7,8,9,10,11};
		List<Carta> mazzo = new ArrayList<Carta>();
		int ind = 0;
		
		
		for (String semi : seme) {
			ind =2;
            for (String nomi : nome) {
            	Carta carta = new Carta(semi, nomi, ind);
            	ind++;
            	//carta.setValore(valore[ind]);
            	mazzo.add(carta);
                       
            }
        }
		
		for (Carta carta : mazzo) {
            System.out.println(carta);
        }

	}
	

}
