package Client;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import it.unibs.pajc.Carta;

public class Client2 {
	Socket mioSocket = null;	
	private int porta = 1235;
	private int state = 0;
	private int tot;
	private Carta cartaDaGiocare;
	private Carta cartaSelezionata;
	private List<Carta> listaCarteInMano;
	
	private DataInputStream in;
	private DataOutputStream out;
	private ObjectInputStream objectIn;
	private ObjectOutputStream objectOut;
	
	private JFrame frame;
    private JLabel[] carteLabels;
    private JLabel punteggioLabel;
    private JLabel msgLabel;
   
    private JPanel cartePanel;
    private JPanel bandaLaterale;
   
    private JButton inviaCartaButton;
    private JComboBox selettore;
    private int index;
    private int index2;
    
	public static void main(String[] args) throws ClassNotFoundException, IOException{		
		Client2 c = new Client2();
		c.connetti();
		c.creaGUI();
		c.comunica();
	}
	
	public void creaGUI() {		
		frame = new JFrame("Briscola");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(620,620);
        // Pannello principale con BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout());
        // Pannello delle carte con sfondo verde
        cartePanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        cartePanel.setBackground(new Color(0x036f37));
        // Etichette per le carte
        carteLabels = new JLabel[3];
        for (int i = 0; i < 3; i++) {
            carteLabels[i] = new JLabel();
            cartePanel.add(carteLabels[i]);
        }
        
      
        
        selettore = new JComboBox();
        selettore.setBounds(80, 80, 80, 80);
        
        
        inviaCartaButton = new JButton("Gioca");
                
        bandaLaterale = new JPanel();
        bandaLaterale.setPreferredSize(new Dimension(150, 400));
        bandaLaterale.setBackground(Color.GRAY);
        
        bandaLaterale.setLayout(new BorderLayout());
        bandaLaterale.add(selettore, BorderLayout.NORTH);
        bandaLaterale.add(inviaCartaButton, BorderLayout.CENTER);
        
        punteggioLabel = new JLabel("Punti: 0");
        msgLabel = new JLabel("-----");
        
        mainPanel.add(msgLabel, BorderLayout.WEST);
        mainPanel.add(punteggioLabel, BorderLayout.NORTH);
        mainPanel.add(cartePanel, BorderLayout.SOUTH); // Posiziona il pannello delle carte in basso
        mainPanel.add(bandaLaterale, BorderLayout.EAST);
        mainPanel.setBackground(new Color(0x036f37));
        
        frame.add(mainPanel);
        frame.setVisible(true);	
    }
	
	public Socket connetti() {
		try 
		{
			System.out.println("[0] Client - Provo a connettermi al server");
			mioSocket = new Socket(InetAddress.getLocalHost(), porta);
			System.out.println("[1] Client - Connesso");		
			in = new DataInputStream(mioSocket.getInputStream());
			out = new DataOutputStream(mioSocket.getOutputStream());
			objectIn = new ObjectInputStream(in);
			objectOut = new ObjectOutputStream(out);				
		} 
		catch (UnknownHostException e) 
		{
			System.out.println("Host sconosciuto");
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			System.out.println("Impossibile stabilire connessione");
			state = 1;
		}		
		return mioSocket;
	}

	public void comunica() throws ClassNotFoundException, IOException{		
		listaCarteInMano = new ArrayList<Carta>();
		
		if (state==0) {
			try 
			{	
				for (int i = 0; i < 3; i++) {
			        Carta cartaRicevuta = (Carta) objectIn.readObject();
			        System.out.println("Carta ricevuta: " + i  + " "+ cartaRicevuta); // Visualizza l'oggetto carta
			        listaCarteInMano.add(cartaRicevuta);
			        String nomeCarta = cartaRicevuta.getNome()+" di "+cartaRicevuta.getSeme();
			        ImageIcon icon = getCardIcon(cartaRicevuta.getSeme(), cartaRicevuta.getValore()); // Sostituisci con il percorso all'immagine della carta
                    carteLabels[i].setIcon(icon);    
                    selettore.insertItemAt(nomeCarta, i);
				}
							
				while(true) {
					
					String messaggioDalServer = in.readUTF();
					System.out.println("Messaggio dal server: " + messaggioDalServer);	
					msgLabel.setText(messaggioDalServer);	
					
					selettore.addActionListener(new ActionListener() {

					    public void actionPerformed(ActionEvent e)
					    {
					    	//index =-1;
					        index = selettore.getSelectedIndex();
					        
					        cartaSelezionata = listaCarteInMano.get(index);
					        selettore.removeItemAt(index);
					        System.out.println("Indice scelto: " + index);
					        try {
								objectOut.writeObject(cartaSelezionata);
								objectOut.flush();
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							
							listaCarteInMano.remove(index);
							// Rimuovi l'icona della carta selezionata dal pannello delle carte
							cartePanel.remove(carteLabels[index]);
							carteLabels[index].setIcon(null);
							cartePanel.revalidate(); // Aggiorna il pannello delle carte
					        
					    }
					});  
					
					
					//index = selettore.getSelectedIndex();
					
					/*inviaCartaButton.addActionListener(new ActionListener() {

					    public void actionPerformed(ActionEvent e)
					    {
					        //Execute when button is pressed
					        System.out.println("You clicked the button");
					        cartaSelezionata = listaCarteInMano.get(index); // Rimuovi la carta selezionata
							
							selettore.removeItemAt(index);
							try {
								
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							
					    }
					});  */
					
					/*int index = giocaCarta(listaCarteInMano);
					cartaSelezionata = listaCarteInMano.get(index); // Rimuovi la carta selezionata
					//String nomeCartaSelezionata = cartaSelezionata.getNome() + " di " + cartaSelezionata.getSeme();
					selettore.removeItemAt(index);
					objectOut.writeObject(cartaSelezionata);
					objectOut.flush();
					listaCarteInMano.remove(index);
					// Rimuovi l'icona della carta selezionata dal pannello delle carte
					cartePanel.remove(carteLabels[index]);
					carteLabels[index].setIcon(null);
					cartePanel.revalidate(); // Aggiorna il pannello delle carte
					*/
					

					String msg2daServer = in.readUTF();
					msgLabel.setText(msg2daServer);
					System.out.println(msg2daServer);
					String msgVincitore = in.readUTF();
					System.out.println("Messaggio dal server: " + msgVincitore);
				
					int msgPunti = in.readInt();
					tot = tot + msgPunti;
					System.out.println("Messaggio del server: punti vinti --> " + msgPunti);
					System.out.println("Punti totali: "+tot);
					punteggioLabel.setText("Punti: " + tot);
									
					Carta cartaPescata = (Carta) objectIn.readObject();
					listaCarteInMano.add(index, cartaPescata);

					// Crea un'etichetta per la carta pescata e aggiungila al pannello delle carte
					JLabel carteLabelPescata = new JLabel();
					ImageIcon icon = getCardIcon(cartaPescata.getSeme(), cartaPescata.getValore());
					carteLabelPescata.setIcon(icon);
					cartePanel.add(carteLabelPescata, index);
					String nomeCartaPescata = cartaPescata.getNome() + " di " + cartaPescata.getSeme();
					selettore.insertItemAt(nomeCartaPescata, index);
					cartePanel.revalidate(); // Aggiorna il pannello delle carte
				
					for(int i=0;i<selettore.getItemCount();i++) {
						System.out.println(selettore.getItemAt(i));
						
					}
					System.out.println(listaCarteInMano.toString());
					
				}	
			} 
			catch (IOException e) {
				e.printStackTrace();
			}
		}
		else {
			return;
		}
	}

	public ImageIcon getCardIcon(String seme, int numero) {
	    String percorso = "carte/" + seme + numero + ".png"; // Assicurati che il formato dell'immagine sia .png
	    ImageIcon icon = new ImageIcon(percorso);
	    return icon;
	}
	
	public int giocaCarta(List<Carta> mazzo) {
	    Scanner sc = new Scanner(System.in);
	    System.out.println(mazzo.toString());
	    System.out.println("Scegli carta (0,1,2): ");
	    int index = sc.nextInt();
	    return index;
	}



}
