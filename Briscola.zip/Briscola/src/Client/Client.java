package Client;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import it.unibs.pajc.Carta;

public class Client {
	Socket mioSocket = null;	
	private int porta = 1235;
	private int state = 0;
	private int tot;
	private Carta cartaDaGiocare;
	private Carta cartaSelezionata;
	private List<Carta> listaCarteInMano;
	
	private DataInputStream in;
	private DataOutputStream out;
	private ObjectInputStream objectIn;
	private ObjectOutputStream objectOut;
	
	private JFrame frame;
    private JLabel[] carteLabels;
    private JLabel punteggioLabel;
    private JLabel msgLabel;
    private JLabel msg2Label;
   
    private JPanel cartePanel;
    private JPanel bandaLaterale;
    
    private int index;
   
    private JComboBox<String> selettoreCarte;
    private JButton inviaCartaButton;
    private DefaultComboBoxModel<String> comboBoxModel;
    
    
	public static void main(String[] args) throws ClassNotFoundException, IOException{		
		Client c = new Client();
		c.connetti();
		c.creaGUI();
		c.comunica();
	}
	
	public void creaGUI() {		
		frame = new JFrame("Briscola");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(620,620);
        // Pannello principale con BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout());
        // Pannello delle carte con sfondo verde
        cartePanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        cartePanel.setBackground(new Color(0x036f37));
        // Etichette per le carte
        carteLabels = new JLabel[3];
        for (int i = 0; i < 3; i++) {
            carteLabels[i] = new JLabel();
            cartePanel.add(carteLabels[i]);
        }
        
        comboBoxModel = new DefaultComboBoxModel<>();
        selettoreCarte = new JComboBox<>(comboBoxModel);
        selettoreCarte.setPreferredSize(new Dimension(110,100));
        selettoreCarte.setBackground(Color.GRAY);
        
        
        
        
        inviaCartaButton = new JButton("Invia");
                
        bandaLaterale = new JPanel();
        bandaLaterale.setPreferredSize(new Dimension(150, 400));
        bandaLaterale.setBackground(Color.GRAY);
        // Utilizza un BorderLayout per pannelloBandaLaterale
        bandaLaterale.setLayout(new BorderLayout());
        bandaLaterale.add(selettoreCarte, BorderLayout.NORTH);
        bandaLaterale.add(inviaCartaButton, BorderLayout.CENTER); 
        // Etichetta per il punteggio
        punteggioLabel = new JLabel("Punti: 0");
        msgLabel = new JLabel("-----");
        msg2Label = new JLabel("-----");
        
        mainPanel.add(msgLabel, BorderLayout.WEST);
        mainPanel.add(punteggioLabel, BorderLayout.NORTH);
        mainPanel.add(cartePanel, BorderLayout.SOUTH); // Posiziona il pannello delle carte in basso
        mainPanel.add(bandaLaterale, BorderLayout.EAST);
        mainPanel.setBackground(new Color(0x036f37));
        
        frame.add(mainPanel);
        frame.setVisible(true);	
    }
	
	public Socket connetti() {
		try 
		{
			System.out.println("[0] Client - Provo a connettermi al server");
			mioSocket = new Socket(InetAddress.getLocalHost(), porta);
			System.out.println("[1] Client - Connesso");		
			in = new DataInputStream(mioSocket.getInputStream());
			out = new DataOutputStream(mioSocket.getOutputStream());
			objectIn = new ObjectInputStream(in);
			objectOut = new ObjectOutputStream(out);				
		} 
		catch (UnknownHostException e) 
		{
			System.out.println("Host sconosciuto");
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			System.out.println("Impossibile stabilire connessione");
			state = 1;
		}		
		return mioSocket;
	}

	public void comunica() throws ClassNotFoundException, IOException{		
		listaCarteInMano = new ArrayList<Carta>();
		
		if (state==0) {
			try 
			{	
				for (int i = 0; i < 3; i++) {
			        Carta cartaRicevuta = (Carta) objectIn.readObject();
			        System.out.println("Carta ricevuta: " + i  + " "+ cartaRicevuta); // Visualizza l'oggetto carta
			        listaCarteInMano.add(cartaRicevuta);
			        String nomeCarta = cartaRicevuta.getNome()+" di "+cartaRicevuta.getSeme();
			        ImageIcon icon = getCardIcon(cartaRicevuta.getSeme(), cartaRicevuta.getValore()); // Sostituisci con il percorso all'immagine della carta
                    carteLabels[i].setIcon(icon);    
                    //comboBoxModel.addElement(nomeCarta);    
                    comboBoxModel.insertElementAt(nomeCarta, i);
				}
							
				while(true) {
					
					String messaggioDalServer = in.readUTF();
					System.out.println("Messaggio dal server: " + messaggioDalServer);	
					msgLabel.setText(messaggioDalServer);	
					
					selettoreCarte.addActionListener(new ActionListener() {
			            public void actionPerformed(ActionEvent e) {
			                //int selectedIndex = selettoreCarte.getSelectedIndex();
			            	index = selettoreCarte.getSelectedIndex();
			            	
			            	
			                if (index >= 0) {
			                    cartaSelezionata = listaCarteInMano.get(index);
			                }
			            }
			        });
					
					inviaCartaButton.addActionListener(new ActionListener() {
			            public void actionPerformed(ActionEvent e) {
			                if (cartaSelezionata != null) {
			                    try {
			                        objectOut.writeObject(cartaSelezionata);
			                        objectOut.flush();
			                        System.out.println("Carta inviata al server: " + cartaSelezionata);
			                        listaCarteInMano.remove(index);
			                        
			                        carteLabels[index].setIcon(null);
			                        cartePanel.remove(carteLabels[index]);
			                        comboBoxModel.removeElementAt(index);
			                        
			                        
			                    } catch (IOException ex) {
			                        ex.printStackTrace();
			                    }
			                }
			            }
			        });



					String msg2daServer = in.readUTF();
					msgLabel.setText(msg2daServer);
					System.out.println(msg2daServer);
					String msgVincitore = in.readUTF();
					System.out.println("Messaggio dal server: " + msgVincitore);
				
					int msgPunti = in.readInt();
					tot = tot + msgPunti;
					System.out.println("Messaggio del server: punti vinti --> " + msgPunti);
					System.out.println("Punti totali: "+tot);
					punteggioLabel.setText("Punti: " + tot);
									
					Carta cartaPescata = (Carta) objectIn.readObject();
					//listaCarteInMano.add(cartaPescata);
					listaCarteInMano.add(index, cartaPescata);
					
					// Aggiungi il nome della carta pescata al ComboBox
					String nomeCartaPescata = cartaPescata.getNome() + " di " + cartaPescata.getSeme();
					
					comboBoxModel.insertElementAt(nomeCartaPescata, index);
					
					ImageIcon iconCartaPescata = getCardIcon(cartaPescata.getSeme(), cartaPescata.getValore());
					
					JLabel cartaPescataLabel = new JLabel();
					
					cartaPescataLabel.setIcon(iconCartaPescata);
					cartePanel.add(cartaPescataLabel, index);
					
					
					cartePanel.repaint();
					
					
				}	
			} 
			catch (IOException e) {
				e.printStackTrace();
			}
		}
		else {
			return;
		}
	}

	public ImageIcon getCardIcon(String seme, int numero) {
	    String percorso = "carte/" + seme + numero + ".png"; // Assicurati che il formato dell'immagine sia .png
	    ImageIcon icon = new ImageIcon(percorso);
	    return icon;
	}


}

